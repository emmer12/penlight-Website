<?php
$config = [
    'appName' => config('app.name'),
    'locale' => $locale = app()->getLocale(),
    'locales' => config('app.locales'),
    'githubAuth' => config('services.github.client_id'),
];
$appJs = mix('dist/js/app.js');
$appCss = mix('dist/css/app.css');
?>
<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title><?php echo e(config('app.name')); ?></title>

  <link rel="stylesheet" href="<?php echo e((str_starts_with($appCss, '//') ? 'http:' : '').$appCss); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/all.css')); ?>">
</head>
<body>
  <div id="app"></div>

  <script>
    window.config = <?php echo json_encode($config, 15, 512) ?>;
  </script>

  <script src="<?php echo e((str_starts_with($appJs, '//') ? 'http:' : '').$appJs); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\penlight\resources\views/spa.blade.php ENDPATH**/ ?>