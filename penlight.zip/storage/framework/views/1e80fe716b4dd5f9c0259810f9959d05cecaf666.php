

   <div style="padding: 30px;">
         <h4 style="font-size: 20px;font-weight:bold;text-align:center">Contact Form Mail</h4>
          <p>Please check your dashboard we have a new sale 🤣</p>
        <div style="font-size: 16px;color: #242424;line-height: 30px;margin-bottom: 34px;">
            <b>From ::</b> <?php echo e($data['name']); ?><br>
            <b>Phone number ::</b>  <?php echo e($data['phone']); ?><br>
            

        </div>
    </div><?php /**PATH C:\xampp\htdocs\penlight\resources\views/mail/new-sale.blade.php ENDPATH**/ ?>