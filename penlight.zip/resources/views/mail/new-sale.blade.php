

   <div style="padding: 30px;">
         <h4 style="font-size: 20px;font-weight:bold;text-align:center">Contact Form Mail</h4>
          <p>Please check your dashboard we have a new sale Love 🤣 </p>
        <div style="font-size: 16px;color: #242424;line-height: 30px;margin-bottom: 34px;">
            <b>From ::</b> {{$data['name']}}<br>
            <b>Phone number ::</b>  {{$data['phone']}}<br>
            {{--
            <b>Message ::</b> {{$data['message']}}<br> --}}

        </div>
    </div>