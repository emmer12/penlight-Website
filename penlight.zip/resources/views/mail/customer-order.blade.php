    <div style="padding: 30px;">
        <div style="text-align: center">
            <img height="70" width="70" src="{{asset('images/check.png')}}" >
        </div>
         <h4 style="font-size: 20px;font-weight:bold;text-align:center">Thank you for your purchase</h4>
         <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero, ad optio! Ad quo deleniti ut quibusdam nihil ex optio laborum nobis corrupti repudiandae sunt tempora animi minus labore, ipsam asperiores!</p>
         <p>You can also download your purchase from the attachment below</p>

         <p>Regard,</p>
         <p>Penlight Novels</p>
    </div>